import React, { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { 
  Download, Share2, Pencil, Trash2, Globe, Lock,
  Users, Calendar, User, Tag, Link, Copy, X
} from 'lucide-react';
import { Card } from '../ui/card';
import { File, FileAccess } from '../../types/files';

export default function FileDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [showShare, setShowShare] = useState(false);

  // Mock file data
  const file: File = {
    id: '1',
    name: 'example.jpg',
    type: 'image',
    size: 2500000,
    url: 'https://example.com/files/example.jpg',
    tags: ['project', 'marketing'],
    access: 'private',
    metadata: {
      dimensions: {
        width: 1920,
        height: 1080
      }
    },
    uploaded_by: 'John Doe',
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString()
  };

  const accessIcons = {
    public: Globe,
    private: Lock,
    team: Users
  };

  const AccessIcon = accessIcons[file.access];

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
      <Card className="w-full max-w-4xl bg-white flex h-[80vh]">
        <div className="flex-1 border-r border-gray-200">
          <div className="h-full flex items-center justify-center bg-gray-100">
            {file.type === 'image' ? (
              <img
                src={file.url}
                alt={file.name}
                className="max-w-full max-h-full object-contain"
              />
            ) : (
              <div className="text-center">
                <FileIcon size={48} className="mx-auto text-gray-400 mb-4" />
                <p className="text-gray-500">Preview not available</p>
              </div>
            )}
          </div>
        </div>

        <div className="w-80 flex flex-col">
          <div className="flex items-center justify-between p-4 border-b">
            <h2 className="text-lg font-semibold">File Details</h2>
            <button
              onClick={() => navigate('/file-manager')}
              className="text-gray-400 hover:text-gray-600"
            >
              <X size={20} />
            </button>
          </div>

          <div className="flex-1 overflow-y-auto p-4">
            <div className="space-y-6">
              <div>
                <h3 className="font-medium mb-2">{file.name}</h3>
                <div className="flex items-center gap-2 text-sm text-gray-500">
                  <AccessIcon size={16} />
                  <span className="capitalize">{file.access}</span>
                </div>
              </div>

              <div className="flex gap-2">
                <button className="btn btn-secondary flex-1 inline-flex items-center justify-center gap-2">
                  <Download size={16} />
                  <span>Download</span>
                </button>
                <button
                  onClick={() => setShowShare(true)}
                  className="btn btn-secondary flex-1 inline-flex items-center justify-center gap-2"
                >
                  <Share2 size={16} />
                  <span>Share</span>
                </button>
              </div>

              <div className="space-y-4">
                <div>
                  <label className="text-sm font-medium text-gray-700">Size</label>
                  <p className="mt-1 text-sm text-gray-900">
                    {(file.size / 1024 / 1024).toFixed(2)} MB
                  </p>
                </div>

                <div>
                  <label className="text-sm font-medium text-gray-700">Dimensions</label>
                  <p className="mt-1 text-sm text-gray-900">
                    {file.metadata.dimensions?.width} × {file.metadata.dimensions?.height}
                  </p>
                </div>

                <div>
                  <label className="text-sm font-medium text-gray-700">Uploaded By</label>
                  <p className="mt-1 text-sm text-gray-900">{file.uploaded_by}</p>
                </div>

                <div>
                  <label className="text-sm font-medium text-gray-700">Upload Date</label>
                  <p className="mt-1 text-sm text-gray-900">
                    {new Date(file.created_at).toLocaleDateString()}
                  </p>
                </div>

                <div>
                  <label className="text-sm font-medium text-gray-700">Tags</label>
                  <div className="mt-1 flex flex-wrap gap-2">
                    {file.tags.map((tag) => (
                      <span
                        key={tag}
                        className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-gray-100 text-gray-800"
                      >
                        {tag}
                      </span>
                    ))}
                    <button className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-gray-100 text-gray-800 hover:bg-gray-200">
                      + Add Tag
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="p-4 border-t bg-gray-50">
            <div className="flex gap-2">
              <button className="btn btn-secondary flex-1 inline-flex items-center justify-center gap-2">
                <Pencil size={16} />
                <span>Edit</span>
              </button>
              <button className="btn btn-secondary flex-1 inline-flex items-center justify-center gap-2 text-red-600 hover:text-red-700">
                <Trash2 size={16} />
                <span>Delete</span>
              </button>
            </div>
          </div>
        </div>
      </Card>
    </div>
  );
}