import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  Grid, List, Search, Filter, Upload, FolderPlus,
  Image, FileText, Video, Music, File as FileIcon,
  ChevronRight, MoreVertical
} from 'lucide-react';
import { Card } from '../ui/card';
import Breadcrumbs from '../Navigation/Breadcrumbs';
import { ViewMode, File, Folder } from '../../types/files';
import FileUpload from './FileUpload';

export default function FileList() {
  const navigate = useNavigate();
  const [viewMode, setViewMode] = useState<ViewMode>('grid');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedFiles, setSelectedFiles] = useState<string[]>([]);
  const [showUpload, setShowUpload] = useState(false);
  const [currentFolder, setCurrentFolder] = useState<Folder | null>(null);

  const getFileIcon = (type: File['type']) => {
    switch (type) {
      case 'image':
        return Image;
      case 'video':
        return Video;
      case 'audio':
        return Music;
      case 'document':
        return FileText;
      default:
        return FileIcon;
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <Breadcrumbs
            items={[
              { label: 'Home', path: '/' },
              { label: 'File Manager', path: '/file-manager', active: true }
            ]}
          />
          <h1 className="mt-2">File Manager</h1>
        </div>

        <div className="flex gap-2">
          <div className="flex rounded-md shadow-sm">
            <button
              onClick={() => setViewMode('grid')}
              className={`px-4 py-2 text-sm font-medium rounded-l-md border ${
                viewMode === 'grid'
                  ? 'bg-primary-50 text-primary-700 border-primary-500'
                  : 'bg-white text-gray-700 border-gray-300 hover:bg-gray-50'
              }`}
            >
              <Grid size={16} />
            </button>
            <button
              onClick={() => setViewMode('list')}
              className={`px-4 py-2 text-sm font-medium rounded-r-md border-t border-r border-b -ml-px ${
                viewMode === 'list'
                  ? 'bg-primary-50 text-primary-700 border-primary-500'
                  : 'bg-white text-gray-700 border-gray-300 hover:bg-gray-50'
              }`}
            >
              <List size={16} />
            </button>
          </div>

          <button
            onClick={() => setShowUpload(true)}
            className="btn btn-primary inline-flex items-center gap-2"
          >
            <Upload size={16} />
            <span>Upload</span>
          </button>

          <button className="btn btn-secondary inline-flex items-center gap-2">
            <FolderPlus size={16} />
            <span>New Folder</span>
          </button>
        </div>
      </div>

      <Card className="overflow-hidden">
        <div className="p-4 border-b border-gray-200">
          <div className="flex gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
                <input
                  type="text"
                  placeholder="Search files..."
                  className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-md"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
            </div>
            <button className="btn btn-secondary inline-flex items-center gap-2">
              <Filter size={16} />
              <span>Filter</span>
            </button>
          </div>
        </div>

        {viewMode === 'grid' ? (
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4 p-4">
            {/* Grid view placeholder */}
            <div className="aspect-square border border-gray-200 rounded-lg p-4 flex flex-col items-center justify-center gap-2 hover:border-primary-500 cursor-pointer">
              <Image size={32} className="text-gray-400" />
              <span className="text-sm text-gray-600 text-center truncate w-full">
                example.jpg
              </span>
            </div>
          </div>
        ) : (
          <div className="divide-y divide-gray-200">
            {/* List view placeholder */}
            <div className="flex items-center px-4 py-3 hover:bg-gray-50">
              <div className="flex-1 flex items-center gap-3">
                <Image size={20} className="text-gray-400" />
                <span className="text-sm">example.jpg</span>
              </div>
              <div className="flex items-center gap-4">
                <span className="text-sm text-gray-500">2.5 MB</span>
                <span className="text-sm text-gray-500">2 days ago</span>
                <button className="p-1 hover:bg-gray-100 rounded">
                  <MoreVertical size={16} />
                </button>
              </div>
            </div>
          </div>
        )}
      </Card>

      {showUpload && (
        <FileUpload
          onClose={() => setShowUpload(false)}
          onUploadComplete={() => {
            setShowUpload(false);
            // Refresh file list
          }}
        />
      )}
    </div>
  );
}