import React from 'react';

export default function FunnelBuilder() {
  return (
    <div>
      <h2 className="text-xl font-semibold">Funnel Builder</h2>
      {/* TODO: Visual funnel flow editor */}
    </div>
  );
}