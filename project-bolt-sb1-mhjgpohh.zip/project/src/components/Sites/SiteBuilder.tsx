import React from 'react';

export default function SiteBuilder() {
  return (
    <div>
      <h2 className="text-xl font-semibold">Site Builder</h2>
      {/* TODO: Visual drag-and-drop page editor */}
    </div>
  );
}