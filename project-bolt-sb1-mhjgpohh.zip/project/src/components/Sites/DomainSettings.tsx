import React from 'react';

export default function DomainSettings() {
  return (
    <div>
      <h2 className="text-xl font-semibold">Domain Settings</h2>
      {/* TODO: Manage custom domains & SSL certificates */}
    </div>
  );
}