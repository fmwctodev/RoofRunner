import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Plus, Search, Filter, Clock, Download } from 'lucide-react';
import { Card } from '../ui/card';
import Breadcrumbs from '../Navigation/Breadcrumbs';
import { Dashboard } from '../../types/reporting';

export default function DashboardList() {
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState('');

  const dashboards: Dashboard[] = [
    {
      id: '1',
      name: 'Executive Overview',
      description: 'Key business metrics and KPIs',
      layout: [],
      permissions: {
        view: ['*'],
        edit: ['admin']
      },
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
      user_id: '1'
    }
  ];

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <Breadcrumbs
            items={[
              { label: 'Home', path: '/' },
              { label: 'Reporting', path: '/reporting' },
              { label: 'Dashboards', path: '/reporting/dashboards', active: true }
            ]}
          />
          <h1 className="mt-2">Dashboards</h1>
        </div>

        <div className="flex gap-2">
          <button
            onClick={() => navigate('/reporting/dashboards/new')}
            className="btn btn-primary inline-flex items-center gap-2"
          >
            <Plus size={16} />
            <span>New Dashboard</span>
          </button>
        </div>
      </div>

      <Card className="overflow-hidden">
        <div className="p-4 border-b border-gray-200">
          <div className="flex gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
                <input
                  type="text"
                  placeholder="Search dashboards..."
                  className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-md"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 p-6">
          {dashboards.map((dashboard) => (
            <Card
              key={dashboard.id}
              className="hover:shadow-lg transition-shadow cursor-pointer"
              onClick={() => navigate(`/reporting/dashboards/${dashboard.id}`)}
            >
              <div className="p-6">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="font-medium">{dashboard.name}</h3>
                  <Clock size={16} className="text-gray-400" />
                </div>
                <p className="text-sm text-gray-600 mb-4">{dashboard.description}</p>
                <div className="flex items-center justify-between text-sm text-gray-500">
                  <span>Last updated: 2 hours ago</span>
                  <span>{dashboard.layout.length} widgets</span>
                </div>
              </div>
            </Card>
          ))}

          <Card
            className="border-2 border-dashed border-gray-300 hover:border-gray-400 transition-colors cursor-pointer"
            onClick={() => navigate('/reporting/dashboards/new')}
          >
            <div className="p-6 flex flex-col items-center justify-center text-center h-full">
              <div className="w-12 h-12 bg-primary-50 text-primary-600 rounded-full flex items-center justify-center mb-3">
                <Plus size={24} />
              </div>
              <h3 className="font-medium text-gray-900">Create Dashboard</h3>
              <p className="text-sm text-gray-500 mt-1">
                Build a custom dashboard
              </p>
            </div>
          </Card>
        </div>
      </Card>
    </div>
  );
}