import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Save, ChevronLeft, Plus, Trash2, Layout, Image, Type, Palette, FileText, Contrast as DragDropContext, Droplet as Droppable, Cable as Draggable, Download, Share2 } from 'lucide-react';
import { Card } from '../ui/card';
import Breadcrumbs from '../Navigation/Breadcrumbs';
import { ReportService } from '../../lib/services/ReportService';

export default function ReportBuilder() {
  const { id } = useParams();
  const navigate = useNavigate();
  const isEditing = Boolean(id);
  
  const [report, setReport] = useState<any>({
    name: '',
    description: '',
    cover: {
      title: '',
      logo: '',
      header: ''
    },
    pages: [
      {
        id: '1',
        name: 'Page 1',
        widgets: []
      }
    ],
    theme: 'default',
    source: 'custom'
  });
  
  const [selectedPage, setSelectedPage] = useState('1');
  const [isSaving, setIsSaving] = useState(false);
  const [showWidgetPicker, setShowWidgetPicker] = useState(false);
  const [availableWidgets, setAvailableWidgets] = useState<any[]>([]);
  const [availableThemes, setAvailableThemes] = useState<any[]>([
    { id: 'default', name: 'Default', colors: { primary: '#3B82F6' } },
    { id: 'dark', name: 'Dark', colors: { primary: '#1F2937' } },
    { id: 'light', name: 'Light', colors: { primary: '#F9FAFB' } },
    { id: 'brand', name: 'Brand', colors: { primary: '#10B981' } }
  ]);

  useEffect(() => {
    if (isEditing) {
      loadReport();
    }
    
    // Load available widgets
    setAvailableWidgets([
      { id: 'revenue-chart', name: 'Revenue Chart', type: 'chart' },
      { id: 'lead-sources', name: 'Lead Sources', type: 'chart' },
      { id: 'conversion-rates', name: 'Conversion Rates', type: 'chart' },
      { id: 'agent-performance', name: 'Agent Performance', type: 'table' },
      { id: 'appointment-summary', name: 'Appointment Summary', type: 'summary' },
      { id: 'call-metrics', name: 'Call Metrics', type: 'metrics' }
    ]);
  }, [id]);

  const loadReport = async () => {
    try {
      const reportData = await ReportService.getReport(id!);
      setReport(reportData);
      if (reportData.pages.length > 0) {
        setSelectedPage(reportData.pages[0].id);
      }
    } catch (error) {
      console.error('Error loading report:', error);
    }
  };

  const handleSave = async () => {
    try {
      setIsSaving(true);
      
      if (isEditing) {
        await ReportService.updateReport(id!, report);
      } else {
        const newReport = await ReportService.createReport(report);
        navigate(`/reporting/${newReport.id}`);
      }
    } catch (error) {
      console.error('Error saving report:', error);
    } finally {
      setIsSaving(false);
    }
  };

  const handleAddPage = () => {
    const newPage = {
      id: crypto.randomUUID(),
      name: `Page ${report.pages.length + 1}`,
      widgets: []
    };
    
    setReport({
      ...report,
      pages: [...report.pages, newPage]
    });
    
    setSelectedPage(newPage.id);
  };

  const handleRenamePage = (pageId: string, newName: string) => {
    setReport({
      ...report,
      pages: report.pages.map((page: any) =>
        page.id === pageId ? { ...page, name: newName } : page
      )
    });
  };

  const handleDeletePage = (pageId: string) => {
    if (report.pages.length <= 1) {
      alert('You cannot delete the only page in the report.');
      return;
    }
    
    const newPages = report.pages.filter((page: any) => page.id !== pageId);
    setReport({
      ...report,
      pages: newPages
    });
    
    if (selectedPage === pageId) {
      setSelectedPage(newPages[0].id);
    }
  };

  const handleAddWidget = (widgetId: string) => {
    const widget = availableWidgets.find(w => w.id === widgetId);
    if (!widget) return;
    
    const currentPage = report.pages.find((page: any) => page.id === selectedPage);
    if (!currentPage) return;
    
    const newWidget = {
      id: crypto.randomUUID(),
      type: widget.type,
      name: widget.name,
      source: widgetId,
      size: { width: 1, height: 1 },
      position: { x: 0, y: currentPage.widgets.length }
    };
    
    const updatedPages = report.pages.map((page: any) =>
      page.id === selectedPage
        ? { ...page, widgets: [...page.widgets, newWidget] }
        : page
    );
    
    setReport({
      ...report,
      pages: updatedPages
    });
    
    setShowWidgetPicker(false);
  };

  const handleRemoveWidget = (pageId: string, widgetId: string) => {
    const updatedPages = report.pages.map((page: any) =>
      page.id === pageId
        ? { ...page, widgets: page.widgets.filter((w: any) => w.id !== widgetId) }
        : page
    );
    
    setReport({
      ...report,
      pages: updatedPages
    });
  };

  const handleDragEnd = (result: any) => {
    if (!result.destination) return;
    
    if (result.type === 'page') {
      const items = Array.from(report.pages);
      const [reorderedItem] = items.splice(result.source.index, 1);
      items.splice(result.destination.index, 0, reorderedItem);
      
      setReport({
        ...report,
        pages: items
      });
    } else if (result.type === 'widget') {
      const pageId = result.source.droppableId;
      const page = report.pages.find((p: any) => p.id === pageId);
      
      if (!page) return;
      
      const widgets = Array.from(page.widgets);
      const [reorderedItem] = widgets.splice(result.source.index, 1);
      widgets.splice(result.destination.index, 0, reorderedItem);
      
      const updatedPages = report.pages.map((p: any) =>
        p.id === pageId ? { ...p, widgets } : p
      );
      
      setReport({
        ...report,
        pages: updatedPages
      });
    }
  };

  const handleThemeChange = (themeId: string) => {
    setReport({
      ...report,
      theme: themeId
    });
  };

  const handleExport = async (format: 'pdf' | 'csv') => {
    try {
      if (!isEditing) {
        alert('Please save the report first before exporting.');
        return;
      }
      
      const downloadUrl = await ReportService.exportReport(id!, format);
      window.open(downloadUrl, '_blank');
    } catch (error) {
      console.error('Error exporting report:', error);
    }
  };

  const currentPage = report.pages.find((page: any) => page.id === selectedPage);

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <Breadcrumbs
            items={[
              { label: 'Home', path: '/' },
              { label: 'Reporting', path: '/reporting' },
              { 
                label: isEditing ? 'Edit Report' : 'New Report', 
                path: isEditing ? `/reporting/${id}` : '/reporting/new', 
                active: true 
              }
            ]}
          />
          <div className="flex items-center gap-4 mt-2">
            <button
              onClick={() => navigate('/reporting')}
              className="text-gray-500 hover:text-gray-700"
            >
              <ChevronLeft size={20} />
            </button>
            <h1>{isEditing ? 'Edit Report' : 'New Report'}</h1>
          </div>
        </div>

        <div className="flex gap-2">
          <button
            onClick={() => handleExport('pdf')}
            className="btn btn-secondary inline-flex items-center gap-2"
            disabled={!isEditing}
          >
            <Download size={16} />
            <span>Export PDF</span>
          </button>
          
          <button
            onClick={handleSave}
            className="btn btn-primary inline-flex items-center gap-2"
            disabled={isSaving}
          >
            <Save size={16} />
            <span>{isSaving ? 'Saving...' : 'Save Report'}</span>
          </button>
        </div>
      </div>

      <div className="grid grid-cols-12 gap-6">
        <div className="col-span-3">
          <Card className="p-4">
            <h3 className="font-medium mb-4">Report Settings</h3>
            
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Report Name
                </label>
                <input
                  type="text"
                  value={report.name}
                  onChange={(e) => setReport({ ...report, name: e.target.value })}
                  className="w-full rounded-md border-gray-300"
                  placeholder="Enter report name"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Description
                </label>
                <textarea
                  value={report.description}
                  onChange={(e) => setReport({ ...report, description: e.target.value })}
                  className="w-full rounded-md border-gray-300"
                  rows={2}
                  placeholder="Enter report description"
                />
              </div>
              
              <div>
                <h4 className="text-sm font-medium text-gray-700 mb-2">Cover Page</h4>
                <div className="space-y-2">
                  <div>
                    <label className="block text-xs text-gray-500 mb-1">
                      Title
                    </label>
                    <input
                      type="text"
                      value={report.cover.title}
                      onChange={(e) => setReport({ 
                        ...report, 
                        cover: { ...report.cover, title: e.target.value } 
                      })}
                      className="w-full rounded-md border-gray-300"
                      placeholder="Cover page title"
                    />
                  </div>
                  
                  <div>
                    <label className="block text-xs text-gray-500 mb-1">
                      Logo URL
                    </label>
                    <div className="flex gap-2">
                      <input
                        type="text"
                        value={report.cover.logo}
                        onChange={(e) => setReport({ 
                          ...report, 
                          cover: { ...report.cover, logo: e.target.value } 
                        })}
                        className="flex-1 rounded-md border-gray-300"
                        placeholder="Logo URL"
                      />
                      <button className="btn btn-secondary p-2">
                        <Image size={16} />
                      </button>
                    </div>
                  </div>
                  
                  <div>
                    <label className="block text-xs text-gray-500 mb-1">
                      Header Text
                    </label>
                    <textarea
                      value={report.cover.header}
                      onChange={(e) => setReport({ 
                        ...report, 
                        cover: { ...report.cover, header: e.target.value } 
                      })}
                      className="w-full rounded-md border-gray-300"
                      rows={2}
                      placeholder="Cover page header text"
                    />
                  </div>
                </div>
              </div>
              
              <div>
                <h4 className="text-sm font-medium text-gray-700 mb-2">Theme</h4>
                <div className="grid grid-cols-2 gap-2">
                  {availableThemes.map(theme => (
                    <button
                      key={theme.id}
                      onClick={() => handleThemeChange(theme.id)}
                      className={`p-2 rounded-md border ${
                        report.theme === theme.id
                          ? 'border-primary-500 bg-primary-50'
                          : 'border-gray-200 hover:border-gray-300'
                      }`}
                    >
                      <div 
                        className="w-full h-4 rounded-sm mb-1"
                        style={{ backgroundColor: theme.colors.primary }}
                      ></div>
                      <span className="text-xs">{theme.name}</span>
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </Card>
          
          <Card className="p-4 mt-4">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-medium">Pages</h3>
              <button
                onClick={handleAddPage}
                className="p-1 text-gray-400 hover:text-gray-600 rounded-full hover:bg-gray-100"
              >
                <Plus size={16} />
              </button>
            </div>
            
            <div className="space-y-2">
              {report.pages.map((page: any, index: number) => (
                <div
                  key={page.id}
                  className={`flex items-center justify-between p-2 rounded-md cursor-pointer ${
                    selectedPage === page.id ? 'bg-primary-50 border border-primary-100' : 'hover:bg-gray-50'
                  }`}
                  onClick={() => setSelectedPage(page.id)}
                >
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-medium text-gray-500">{index + 1}</span>
                    <input
                      type="text"
                      value={page.name}
                      onChange={(e) => handleRenamePage(page.id, e.target.value)}
                      className={`text-sm border-none focus:ring-0 bg-transparent ${
                        selectedPage === page.id ? 'text-primary-700' : 'text-gray-700'
                      }`}
                      onClick={(e) => e.stopPropagation()}
                    />
                  </div>
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      handleDeletePage(page.id);
                    }}
                    className="p-1 text-gray-400 hover:text-gray-600 rounded-full hover:bg-gray-100"
                  >
                    <Trash2 size={14} />
                  </button>
                </div>
              ))}
            </div>
          </Card>
        </div>

        <div className="col-span-9">
          <Card className="p-6">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-lg font-medium">{currentPage?.name || 'Page'}</h2>
              <button
                onClick={() => setShowWidgetPicker(true)}
                className="btn btn-primary inline-flex items-center gap-2"
              >
                <Plus size={16} />
                <span>Add Widget</span>
              </button>
            </div>
            
            {currentPage?.widgets.length === 0 ? (
              <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center">
                <Layout size={48} className="mx-auto text-gray-400 mb-4" />
                <p className="text-gray-500 mb-2">No widgets added to this page yet</p>
                <p className="text-sm text-gray-400">
                  Click "Add Widget" to start building your report
                </p>
              </div>
            ) : (
              <div className="space-y-4">
                {currentPage?.widgets.map((widget: any) => (
                  <div
                    key={widget.id}
                    className="border rounded-lg p-4 hover:shadow-sm transition-shadow"
                  >
                    <div className="flex items-center justify-between mb-2">
                      <h3 className="font-medium">{widget.name}</h3>
                      <button
                        onClick={() => handleRemoveWidget(selectedPage, widget.id)}
                        className="p-1 text-gray-400 hover:text-gray-600 rounded-full hover:bg-gray-100"
                      >
                        <Trash2 size={16} />
                      </button>
                    </div>
                    
                    <div className="h-48 bg-gray-50 rounded-md flex items-center justify-center">
                      <p className="text-gray-400">Widget preview</p>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </Card>
        </div>
      </div>

      {showWidgetPicker && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <Card className="w-full max-w-2xl bg-white p-6">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-semibold">Add Widget</h2>
              <button
                onClick={() => setShowWidgetPicker(false)}
                className="text-gray-400 hover:text-gray-600"
              >
                <X size={20} />
              </button>
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              {availableWidgets.map(widget => (
                <button
                  key={widget.id}
                  onClick={() => handleAddWidget(widget.id)}
                  className="text-left p-4 border rounded-lg hover:border-primary-500 hover:shadow-sm transition-all"
                >
                  <h3 className="font-medium">{widget.name}</h3>
                  <p className="text-sm text-gray-500 mt-1">
                    {widget.type === 'chart' ? 'Chart widget' : 
                     widget.type === 'table' ? 'Table widget' : 
                     widget.type === 'summary' ? 'Summary widget' : 
                     'Metrics widget'}
                  </p>
                </button>
              ))}
            </div>
          </Card>
        </div>
      )}
    </div>
  );
}