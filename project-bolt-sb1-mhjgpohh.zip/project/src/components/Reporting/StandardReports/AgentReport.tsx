import React, { useState, useEffect } from 'react';
import { Users, Filter, Download, Search, RefreshCw } from 'lucide-react';
import { Card } from '../../ui/card';
import { AgentReportService } from '../../../lib/services/AgentReportService';

export default function AgentReport() {
  const [data, setData] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [timeRange, setTimeRange] = useState('last_30_days');
  const [filters, setFilters] = useState<{
    dateRange?: { start: string; end: string };
    agents?: string[];
    metrics?: string[];
  }>({});

  useEffect(() => {
    loadData();
  }, [timeRange, filters]);

  const loadData = async () => {
    try {
      setLoading(true);
      const reportData = await AgentReportService.list(filters);
      setData(reportData);
    } catch (error) {
      console.error('Error loading agent report:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleExport = async (format: 'csv' | 'pdf') => {
    try {
      // Implement export functionality
      alert(`Exporting agent report as ${format}...`);
    } catch (error) {
      console.error('Error exporting report:', error);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-semibold">Agent Performance Report</h2>
        <div className="flex gap-2">
          <select
            value={timeRange}
            onChange={(e) => setTimeRange(e.target.value)}
            className="rounded-md border-gray-300"
          >
            <option value="last_7_days">Last 7 days</option>
            <option value="last_30_days">Last 30 days</option>
            <option value="last_90_days">Last 90 days</option>
            <option value="year_to_date">Year to date</option>
          </select>
          <button
            onClick={() => handleExport('csv')}
            className="btn btn-secondary inline-flex items-center gap-2"
          >
            <Download size={16} />
            <span>Export</span>
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card className="p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-medium">Calls</h3>
            <span className="text-2xl font-bold">1,247</span>
          </div>
          <div className="h-1 bg-gray-200 rounded-full mb-2">
            <div className="h-1 bg-primary-500 rounded-full" style={{ width: '75%' }}></div>
          </div>
          <div className="flex justify-between text-sm text-gray-500">
            <span>+12% vs last period</span>
            <span>Target: 1,500</span>
          </div>
        </Card>

        <Card className="p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-medium">Appointments</h3>
            <span className="text-2xl font-bold">342</span>
          </div>
          <div className="h-1 bg-gray-200 rounded-full mb-2">
            <div className="h-1 bg-green-500 rounded-full" style={{ width: '60%' }}></div>
          </div>
          <div className="flex justify-between text-sm text-gray-500">
            <span>+8% vs last period</span>
            <span>Target: 400</span>
          </div>
        </Card>

        <Card className="p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-medium">Deals</h3>
            <span className="text-2xl font-bold">87</span>
          </div>
          <div className="h-1 bg-gray-200 rounded-full mb-2">
            <div className="h-1 bg-blue-500 rounded-full" style={{ width: '70%' }}></div>
          </div>
          <div className="flex justify-between text-sm text-gray-500">
            <span>+15% vs last period</span>
            <span>Target: 100</span>
          </div>
        </Card>

        <Card className="p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-medium">Revenue</h3>
            <span className="text-2xl font-bold">$125K</span>
          </div>
          <div className="h-1 bg-gray-200 rounded-full mb-2">
            <div className="h-1 bg-yellow-500 rounded-full" style={{ width: '80%' }}></div>
          </div>
          <div className="flex justify-between text-sm text-gray-500">
            <span>+20% vs last period</span>
            <span>Target: $150K</span>
          </div>
        </Card>
      </div>

      <Card className="p-6">
        <div className="flex gap-4 mb-6">
          <div className="flex-1">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
              <input
                type="text"
                placeholder="Search agents..."
                className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-md"
              />
            </div>
          </div>
          <button className="btn btn-secondary inline-flex items-center gap-2">
            <Filter size={16} />
            <span>Filter</span>
          </button>
          <button 
            onClick={loadData}
            className="btn btn-secondary inline-flex items-center gap-2"
          >
            <RefreshCw size={16} />
            <span>Refresh</span>
          </button>
        </div>

        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Agent
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Calls
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Appointments
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Deals
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Revenue
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Conversion Rate
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Avg Deal Size
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {loading ? (
                <tr>
                  <td colSpan={7} className="px-6 py-4 text-center text-gray-500">
                    Loading agent data...
                  </td>
                </tr>
              ) : data.length === 0 ? (
                <tr>
                  <td colSpan={7} className="px-6 py-4 text-center text-gray-500">
                    No agent data found
                  </td>
                </tr>
              ) : (
                data.map((agent, index) => (
                  <tr key={index} className="hover:bg-gray-50">
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center">
                        <div className="flex-shrink-0 h-10 w-10 rounded-full bg-gray-200 flex items-center justify-center">
                          {agent.name.charAt(0)}
                        </div>
                        <div className="ml-4">
                          <div className="text-sm font-medium text-gray-900">{agent.name}</div>
                          <div className="text-sm text-gray-500">{agent.role}</div>
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {agent.calls}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {agent.appointments}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {agent.deals}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      ${agent.revenue.toLocaleString()}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {agent.conversion_rate}%
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      ${agent.avg_deal_size.toLocaleString()}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </Card>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card className="p-6">
          <h3 className="text-lg font-medium mb-4">Agent Leaderboard</h3>
          <div className="h-64 flex items-center justify-center border border-dashed border-gray-300 rounded-lg">
            <p className="text-gray-500">Agent leaderboard chart will be displayed here</p>
          </div>
        </Card>

        <Card className="p-6">
          <h3 className="text-lg font-medium mb-4">Performance Trends</h3>
          <div className="h-64 flex items-center justify-center border border-dashed border-gray-300 rounded-lg">
            <p className="text-gray-500">Performance trends chart will be displayed here</p>
          </div>
        </Card>
      </div>
    </div>
  );
}